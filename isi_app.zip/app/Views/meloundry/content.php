<?php
echo $this->extend('template/index');
echo $this->section('content');
?>
<p>content meloundry</p>
<?php
echo $this->endSection();
